# -------------------------------------------------#
# Title: Working with Functions and Classes
# Dev:   MFenn
# Date:  Nov 23, 2018
# ChangeLog: (Who, When, What)
#  none yet
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
objFileName = "ToDo.txt"
# strData = A row of text data from the file
strData = ""
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {}
# lstTable = A dictionary that acts as a 'table' of rows
lstTable = []
# strMenu = A menu of user options
# strChoice = Capture the user option selection
strChoice = ""

# -- Processing --#
class ProcessData(object):

    #Define the function
    # Step 1 Function, Parameter is the text filename
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"
    @staticmethod
    def LoadData(objFileName):
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  #read a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()

    #Define the function
    # Step 3 Function, Parameter is the List variable
    # Show the current items in the table
    @staticmethod
    def ShowData(lst):
        print("The current tasks to do follow:")
        print("*******************************")
        for item in lst:
            print(item["Task"] + "(" + item["Priority"] + ")")
        print("*******************************")
        print()

    #Define the function
    # Step 4 Function, Parameters are the task to add and the priority
    # Add a new item to the list/Table
    # query user for information
    # define new dictionary item using input and append to dictionary
    @staticmethod
    def AddData(strTask, strPr):
        dicRowNew = {"Task": strTask, "Priority": strPr}
        lstTable.append(dicRowNew)

    #Define the function
    # Step 5 Function, Parameter is the task to be removed, Return value determines message to print
    # Remove an item from the list/Table
    # query user for information
    @staticmethod
    def RemoveData(strRemTask):
        # verify task is in the dictionary
        #initialize variables
        blnTaskInDic = False
        intItemNo = 0
        # task found in dictionary (if not return value remains False)
        for item in lstTable:
            if strRemTask == item["Task"]:
                del lstTable[intItemNo]
                blnTaskInDic = True
            else:
                intItemNo = intItemNo + 1
        return blnTaskInDic

    #Define the function
    # Step 6 Function, Parameter is the text filename
    # Save tasks to a text file
    @staticmethod
    def SaveData(objFileName):
        objFile = open(objFileName, "w")
        for item in lstTable:
            objFile.write(item["Task"] + "," + item["Priority"] + "\n")
        objFile.close()

#Step 1 Load data from text file into list
ProcessData.LoadData(objFileName)

# -- Presentation (Input/Output) --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    if (strChoice.strip() == '1'):
        ProcessData.ShowData(lstTable)#Step 3
        continue
    elif (strChoice.strip() == '2'):
        strAddedTask = input("What is the task you would like to add? - ")
        strAddedTaskPr = input("What is the priority (high/low)? - ")
        ProcessData.AddData(strAddedTask, strAddedTaskPr)#Step 4
        # display updated list to user
        print("The task has been added.")
        print("The current tasks to do follow:")
        print("*******************************")
        for item in lstTable:
            print(item["Task"] + "(" + item["Priority"] + ")")
        print("*******************************")
        print()
        continue
    elif (strChoice.strip() == '3'):
        strRemoveTask = input("What is the task you would like to remove? - ")
        #Step 5
        # display updated list to user if task found in dictionary based on return variable
        if ProcessData.RemoveData(strRemoveTask) == True:
            print("The task has been removed.")
            print("The current tasks to do follow:")
            print("*******************************")
            for item in lstTable:
                print(item["Task"] + "(" + item["Priority"] + ")")
            print("*******************************")
            print()
        # task not found in dictionary
        else:
            print("Task not found in list.  Nothing has been removed.")
            print()
        continue
    elif (strChoice.strip() == '4'):
        ProcessData.SaveData(objFileName)#Step 6
        print("List saved to the file ToDo.txt.")
        continue
    elif (strChoice.strip() == '5'):
        break  # and Exit the program
