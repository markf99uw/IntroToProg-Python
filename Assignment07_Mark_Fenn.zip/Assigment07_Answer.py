# -------------------------------------------------#
# Title: Error Handling and Pickling
# Dev:   MFenn
# Date:  Nov 29, 2018
# ChangeLog: (Who, When, What)
#  none yet
# -------------------------------------------------#

'''
This script will demonstrate error handling and pickling
'''

#load in the pickle module
import pickle

# -- Data --#
#Initialize values
strBoardType = None
floatBoardLength = 0
lstBoard = None
filename = "Boards.dat"
blnGoodInput = False#use this as flag for proper board length input

#I/O Presentation
print("Creating a board list: \n")
strBoardType = str(input("Enter the type of board, e.g. 2x4: "))
while blnGoodInput is False:
    try:
        floatBoardLength = float(input("Enter the board length in feet: "))
        blnGoodInput = True#good input means looping can cease
    except ValueError:
        print("The length needs to be a number.  Re-enter length as a number value.")
print("You are adding a " + str(floatBoardLength) + " foot long " + strBoardType + " to the list")

# Process data
# Assemble list from inputs
lstBoard = [strBoardType, floatBoardLength]
# Open data file for writing in binary mode, dump in the list data, then close the file
TempFile = open(filename, "wb")
pickle.dump(lstBoard, TempFile)
TempFile.close()

# Load the pickled file to confirm data was written
TempFile2 = open(filename, "rb")
lstData2 = pickle.load(TempFile2)
print(str(lstData2) + " is now in the list")
TempFile2.close()
